import { state } from '../core/state.js';
import { nodeDefs, uid, makeNode, DEFAULT_VOICE_ID } from '../core/node-defs.js';
import { nodeById, topoOrder, connectReferenceNode, syncReferenceFanOut } from '../core/graph.js';
import { buildSceneGraph, DEFAULT_FILM_TRANSITION } from '../core/film-graph.js';
import { $, setRunStatus } from './dom.js';
import { saveState } from './persistence.js';
import { createUndoSnapshot } from './undo.js';
import { render } from './render.js';
import { ensureDockTimeline, syncTimelineDock, toggleTimeline } from './timeline.js';

export function addNode(type, x = 250 + Math.random() * 220, y = 160 + Math.random() * 180) {
  const dockTimeline =
    type === 'timeline' && state.nodes.find(node => node.type === 'timeline' && node.data?.dockOnly);
  if (dockTimeline) {
    createUndoSnapshot('Thêm node Timeline');
    dockTimeline.data.dockOnly = false;
    dockTimeline.x = x;
    dockTimeline.y = y;
    render();
    if ($('#timelineDock').classList.contains('collapsed')) toggleTimeline();
    return;
  }
  const data =
    type === 'prompt'
      ? { text: 'Describe what you want Muse to generate...' }
      : type === 'negativePrompt'
        ? { text: 'blurry, low quality, distorted anatomy, extra fingers, text, watermark' }
        : type === 'textAppend'
          ? { text: 'cinematic lighting, detailed composition' }
          : type === 'textConcat'
            ? { separator: ', ' }
            : type === 'imageResize'
              ? { width: 1024, height: 1024, fit: 'cover' }
              : type === 'generateImage'
                ? { model: 'muse-image', size: '1:1', status: 'idle' }
                : type === 'generateVideo'
                  ? { model: 'muse-video', size: '16:9', duration: 5, continuity: false, status: 'idle' }
                  : type === 'timeline'
                    ? { clipOrder: [], durations: {} }
                    : type === 'voiceover'
                      ? { text: '', voiceId: DEFAULT_VOICE_ID, speed: 1, status: 'idle' }
                      : {};
  createUndoSnapshot(`Thêm ${nodeDefs[type]?.title || 'node'}`);
  const node = { id: uid(type), type, x, y, data };
  state.nodes.push(node);
  if (type === 'references') syncReferenceFanOut(node);
  else if (['generateImage', 'generateVideo'].includes(type)) {
    const references = state.nodes.find(item => item.type === 'references');
    if (references) connectReferenceNode(references, node);
  }
  render();
  if (type === 'timeline') {
    syncTimelineDock();
    if ($('#timelineDock').classList.contains('collapsed')) toggleTimeline();
  }
}

export function addTextNote(x = 250 + Math.random() * 220, y = 160 + Math.random() * 180) {
  createUndoSnapshot('Thêm ghi chú');
  const note = { id: uid('note'), x, y, text: 'Viết ghi chú…', width: 260, height: 160 };
  state.notes.push(note);
  render();
  saveState();
  setRunStatus('Đã thêm ghi chú vào canvas.', 'ok');
}

export function removeNode(id) {
  const existing = nodeById(id);
  if (!existing) return;
  createUndoSnapshot(`Xoá ${nodeDefs[existing.type]?.title || 'node'}`);
  state.nodes = state.nodes.filter(n => n.id !== id);
  state.edges = state.edges.filter(e => e.source !== id && e.target !== id);
  state.selectedNodeIds = state.selectedNodeIds.filter(nodeId => nodeId !== id);
  if (state.selectedNodeId === id) state.selectedNodeId = state.selectedNodeIds.at(-1) || null;
  render();
  syncTimelineDock();
}

export function selectNode(id, { toggle = false, add = false } = {}) {
  let ids = [...state.selectedNodeIds];
  if (toggle) {
    ids = ids.includes(id) ? ids.filter(item => item !== id) : [...ids, id];
  } else if (add) {
    if (!ids.includes(id)) ids.push(id);
  } else ids = [id];
  state.selectedNodeIds = ids;
  state.selectedNodeId = ids.at(-1) || null;
  document
    .querySelectorAll('.node')
    .forEach(el => el.classList.toggle('selected', ids.includes(el.dataset.id)));
}
export function removeSelectedNodes() {
  const ids = new Set(state.selectedNodeIds);
  if (!ids.size && state.selectedNodeId) ids.add(state.selectedNodeId);
  if (!ids.size) return;
  createUndoSnapshot(`Xoá ${ids.size} node`);
  state.nodes = state.nodes.filter(node => !ids.has(node.id));
  state.edges = state.edges.filter(edge => !ids.has(edge.source) && !ids.has(edge.target));
  state.selectedNodeIds = [];
  state.selectedNodeId = null;
  render();
  saveState();
}

export function buildSceneNodesFromScript() {
  const status = $('#scriptImportStatus');
  const baseY = Math.max(40, ...state.nodes.filter(node => !node.data?.dockOnly).map(node => node.y + 360));
  const graph = buildSceneGraph($('#scriptInput').value, { baseY });
  if (!graph) {
    status.className = 'error';
    status.textContent =
      'Không tìm thấy cảnh nào. Hãy dùng tiêu đề như “CẢNH 1 (0:00–0:07): Tên cảnh” và thêm Prompt ảnh hoặc Prompt video.';
    return;
  }
  createUndoSnapshot('Tạo node từ kịch bản');
  state.nodes.push(...graph.nodes);
  state.edges.push(...graph.edges);
  let made = graph.nodes.length;
  let references = state.nodes.find(node => node.type === 'references');
  if (!references) {
    const minX = Math.min(80, ...state.nodes.filter(node => !node.data?.dockOnly).map(node => node.x));
    references = makeNode('references', minX - 360, baseY);
    references.data = {};
    state.nodes.push(references);
    made++;
  }
  syncReferenceFanOut(references);
  const timeline = ensureDockTimeline();
  timeline.data.clipOrder = graph.videos.map(item => item.node.id);
  timeline.data.durations = timeline.data.durations || {};
  graph.videos.forEach(({ node, seconds }) => {
    timeline.data.durations[node.id] = seconds;
  });
  if (graph.videos.length > 1 && !timeline.data.transition)
    timeline.data.transition = { ...DEFAULT_FILM_TRANSITION };
  $('#scriptModal').classList.add('hidden');
  render();
  saveState();
  if ($('#timelineDock').classList.contains('collapsed')) toggleTimeline();
  const castCount = graph.cast.length;
  setRunStatus(
    `Đã tạo ${castCount ? `${castCount} ảnh tham chiếu nhân vật · ` : ''}${graph.scenes.length} cảnh · ${made} node · ${graph.videos.length} clip video đã xếp trên Timeline.`,
    'ok',
  );
}

export function arrangeNodes() {
  try {
    const order = topoOrder().filter(id => !nodeById(id)?.data?.dockOnly),
      level = new Map(order.map(id => [id, 0]));
    for (const id of order)
      for (const edge of state.edges.filter(e => e.source === id && level.has(e.target)))
        level.set(edge.target, Math.max(level.get(edge.target) || 0, (level.get(id) || 0) + 1));
    const groups = new Map();
    for (const id of order) {
      const l = level.get(id) || 0;
      if (!groups.has(l)) groups.set(l, []);
      groups.get(l).push(id);
    }
    createUndoSnapshot('Sắp xếp node');
    for (const [l, ids] of groups.entries())
      ids.forEach((id, row) => {
        const node = nodeById(id);
        node.x = 70 + l * 350;
        node.y = 60 + row * 260;
      });
    render();
    setRunStatus('Đã sắp xếp node theo thứ tự workflow.', 'ok');
  } catch (error) {
    setRunStatus(error.message, 'error');
  }
}
