import { state } from '../core/state.js';
import { workflowFromScript } from '../core/film-graph.js';
import { classifyError } from '../core/job-errors.js';
import {
  HEARTBEAT_MS,
  WATCHDOG_MS,
  jobOutputKey,
  nextAttempt,
  recordOutcome,
  runFailure,
} from '../core/jobs.js';
import { jobMediaPrefix, lockFinishedSteps } from '../core/checkpoint.js';
import { isMuseUrl } from '../core/worker-tabs.js';
import { $, runStatus, setRunStatus } from './dom.js';
import { dehydrateNodeMedia } from './media-store.js';
import { prepareMuseTab } from './muse-client.js';
import { enableWorkerMode, loadWorkflowObject, readSavedSettings, workflowSnapshot } from './persistence.js';
import { onRunStep } from './run-panel.js';
import { executeWorkflow, stopGeneration } from './runner.js';
import { exportTimelineVideo, stopTimelineExport } from './timeline-export.js';
import {
  claimJob,
  finishJob,
  getQueueControl,
  getSeries,
  updateJob,
  updateQueueControl,
} from './library-store.js';

const CHECKPOINT_DELAY_MS = 5000;
const LOST_LEASE = 'Another worker took over this episode.';
const worker = { id: '', museTabId: 0 };
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const kindError = (message, kind) => Object.assign(new Error(message), { kind });

function banner(text) {
  $('#workerBanner').textContent = `Worker ${worker.id}: ${text}. Keep this tab and its Muse window open.`;
}

function abortRun() {
  if (state.isRunning) stopGeneration(state.activeGenerationId);
  state.generationAbortController?.abort();
  stopTimelineExport();
}

function runProgress() {
  const steps = state.run?.steps || [];
  return {
    done: steps.filter(step => !['pending', 'running'].includes(step.status)).length,
    total: steps.length,
    current: steps.find(step => step.status === 'running')?.label || '',
  };
}

async function owned(update) {
  const job = await update;
  if (!job) throw kindError(LOST_LEASE, 'lost');
  return job;
}

async function saveCheckpoint(jobId) {
  await owned(updateJob(jobId, {}, { owner: worker.id }));
  const snapshot = workflowSnapshot();
  await dehydrateNodeMedia(snapshot.nodes, { keyPrefix: jobMediaPrefix(jobId) });
  return owned(updateJob(jobId, { checkpoint: snapshot, progress: runProgress() }, { owner: worker.id }));
}

async function ensureMuseTab(control) {
  const tab = await chrome.tabs.get(worker.museTabId).catch(() => null);
  if (tab && isMuseUrl(tab.url || tab.pendingUrl)) return;
  const museWindow = await chrome.windows.create({
    url: control.museHomeUrl,
    focused: false,
    width: 560,
    height: 820,
  });
  worker.museTabId = museWindow.tabs[0].id;
  state.pinnedMuseTabId = worker.museTabId;
  await chrome.tabs.update(worker.museTabId, { autoDiscardable: false }).catch(() => {});
  history.replaceState(null, '', `?worker=${worker.id}&muse=${worker.museTabId}`);
}

async function openEpisode(job, control) {
  let workflow;
  if (job.checkpoint) workflow = lockFinishedSteps(structuredClone(job.checkpoint));
  else {
    const series = await getSeries(job.seriesId);
    workflow = workflowFromScript(job.script, { characterImages: series?.characters || {} });
  }
  if (!(await loadWorkflowObject(workflow, { label: job.title })))
    throw kindError('Could not open this episode.', 'script');
  const shared = await readSavedSettings();
  state.settings = {
    ...state.settings,
    autoRetry: shared.autoRetry,
    museTabs: 1,
    cooldownSec: control.cooldownSec,
  };
}

async function runJob(job, control) {
  const startedAt = Date.now();
  const phase = new AbortController();
  let lastProgressAt = startedAt,
    stopReason = '',
    finished = false,
    checkpointTimer = 0,
    checkpointing = Promise.resolve();
  const abortAll = reason => {
    if (finished || stopReason) return;
    stopReason = reason;
    abortRun();
    phase.abort();
  };
  const queueCheckpoint = () => {
    if (checkpointTimer) return;
    checkpointTimer = setTimeout(() => {
      checkpointTimer = 0;
      checkpointing = checkpointing.then(() => saveCheckpoint(job.id)).catch(() => {});
    }, CHECKPOINT_DELAY_MS);
  };
  const stopListening = onRunStep(step => {
    lastProgressAt = Date.now();
    if (step.status === 'done') queueCheckpoint();
  });
  const heartbeat = setInterval(
    async () => {
      const current = await updateJob(
        job.id,
        { heartbeatAt: Date.now(), progress: runProgress() },
        { owner: worker.id },
      ).catch(() => null);
      const latest = await getQueueControl().catch(() => control);
      if (finished) return;
      if (!current) abortAll('lost');
      else if (Date.now() - lastProgressAt > WATCHDOG_MS) abortAll('watchdog');
      else if (latest.abortRunning) abortAll('stop');
    },
    Math.min(HEARTBEAT_MS, control.leaseMs / 3),
  );
  banner(`running ${job.title}`);
  try {
    await ensureMuseTab(control);
    await prepareMuseTab(worker.museTabId, control.museHomeUrl);
    await openEpisode(job, control);
    lastProgressAt = Date.now();
    state.run = null;
    await executeWorkflow();
    clearTimeout(checkpointTimer);
    checkpointTimer = 0;
    await checkpointing;
    if (stopReason === 'lost') return;
    await saveCheckpoint(job.id);
    const failure = runFailure(state.run, runStatus.textContent);
    if (failure) throw kindError(failure.message, failure.kind);
    await owned(updateJob(job.id, { status: 'exporting', heartbeatAt: Date.now() }, { owner: worker.id }));
    banner(`exporting ${job.title}`);
    lastProgressAt = Date.now();
    const exported = await navigator.locks.request('museta-ffmpeg', { signal: phase.signal }, () =>
      exportTimelineVideo({ format: 'mp4', download: false }),
    );
    if (stopReason) throw kindError('The MP4 export was stopped.', 'stopped');
    if (!exported || !state.timelineExportUrl)
      throw kindError('The episode ran but the MP4 could not be exported.', 'export');
    const blob = await (await fetch(state.timelineExportUrl)).blob();
    const endedAt = Date.now();
    await owned(
      finishJob(job.id, worker.id, jobOutputKey(job), blob, current => ({
        status: 'review',
        outputKey: jobOutputKey(job),
        endedAt,
        runMs: (current.runMs || 0) + endedAt - startedAt,
        workerId: null,
        error: '',
        errorKind: '',
        progress: runProgress(),
      })),
    );
    await updateQueueControl(current => recordOutcome(current, 'ok'));
  } catch (error) {
    if (stopReason === 'lost' || error?.kind === 'lost') return;
    const kind =
      stopReason === 'stop'
        ? 'stopped'
        : stopReason === 'watchdog'
          ? 'timeout'
          : error?.kind || classifyError(error?.message || String(error));
    const message =
      stopReason === 'watchdog'
        ? `No progress for ${WATCHDOG_MS / 60_000} minutes, so the watchdog stopped the run.`
        : error?.message || String(error);
    const endedAt = Date.now();
    await updateJob(
      job.id,
      current => ({
        ...nextAttempt(current, kind, endedAt, control.maxAttempts).patch,
        error: message,
        errorKind: kind,
        runMs: (current.runMs || 0) + endedAt - startedAt,
      }),
      { owner: worker.id },
    );
    if (kind !== 'stopped') await updateQueueControl(current => recordOutcome(current, kind));
  } finally {
    finished = true;
    clearInterval(heartbeat);
    clearTimeout(checkpointTimer);
    stopListening();
  }
}

export async function initWorker(params) {
  worker.id = params.get('worker');
  worker.museTabId = Number(params.get('muse'));
  enableWorkerMode();
  document.body.dataset.mode = 'worker';
  document.body.dataset.view = 'canvas';
  state.pinnedMuseTabId = worker.museTabId;
  $('#workerBanner').hidden = false;
  for (;;) {
    const control = await getQueueControl().catch(() => null);
    if (!control || control.paused) {
      banner(control ? 'the queue is paused' : 'waiting for the library');
      await sleep(control?.pollMs || 10_000);
      continue;
    }
    const job = await claimJob(worker.id, Date.now()).catch(() => null);
    if (!job) {
      banner('waiting for episodes');
      await sleep(control.pollMs);
      continue;
    }
    await runJob(job, control).catch(error =>
      setRunStatus(`Worker ${worker.id} could not record ${job.title}: ${error?.message || error}`, 'error'),
    );
  }
}
