# Third-party notices

## FFmpeg WebAssembly core

Museta bundles the single-thread FFmpeg WebAssembly core from `@ffmpeg/core` 0.12.10 (`vendor/ffmpeg/ffmpeg-core.js` and `vendor/ffmpeg/ffmpeg-core.wasm`). This component is licensed under **GNU General Public License v2.0 or later (GPL-2.0-or-later)**. A copy of GPL v2 is included at [licenses/GPL-2.0.txt](licenses/GPL-2.0.txt).

- FFmpeg.wasm source and build files: https://github.com/ffmpegwasm/ffmpeg.wasm/tree/v0.12.10
- FFmpeg source version used by this release: n5.1.4
- FFmpeg source: https://github.com/ffmpegwasm/ffmpeg.wasm-core/tree/n5.1.4-wasm
- Package: https://www.npmjs.com/package/@ffmpeg/core/v/0.12.10
- Package integrity: `sha512-dzNplnn2Nxle2c2i2rrDhqcB19q9cglCkWnoMTDN9Q9l3PvdjZWd1HfSPjCNWc/p8Q3CT+Es9fWOR0UhAeYQZA==`

The bundled FFmpeg core includes FFmpeg n5.1.4 and codec libraries including x264 and x265. Museta is also distributed under GPL-2.0-or-later. Redistribution of the complete extension must comply with GPL-2.0-or-later requirements, including providing the corresponding source for the GPL-covered distribution.

## FFmpeg.wasm JavaScript wrapper

`vendor/ffmpeg/ffmpeg.js` and `vendor/ffmpeg/814.ffmpeg.js` are from `@ffmpeg/ffmpeg` 0.12.15 and are licensed under the MIT License. A copy is included at [licenses/MIT.txt](licenses/MIT.txt).

- Source: https://github.com/ffmpegwasm/ffmpeg.wasm/tree/v0.12.15/packages/ffmpeg
- Package: https://www.npmjs.com/package/@ffmpeg/ffmpeg/v/0.12.15
- Package integrity: `sha512-1C8Obr4GsN3xw+/1Ww6PFM84wSQAGsdoTuTWPOj2OizsRDLT4CXTaVjPhkw6ARyDus1B9X/L2LiXHqYYsGnRFw==`

## Be Vietnam Pro font

`vendor/fonts/BeVietnamPro-ExtraBold.ttf` is used to burn bilingual subtitles into MP4 exports. It is Copyright 2021 The Be Vietnam Pro Project Authors and licensed under the **SIL Open Font License 1.1**. A copy is included at [licenses/OFL-1.1.txt](licenses/OFL-1.1.txt).

- Source: https://github.com/bettergui/BeVietnamPro
- File: https://github.com/google/fonts/tree/main/ofl/bevietnampro
